//const express = require('express');
const { MongoClient } = require('mongodb');

//const app = express();


const dbname = "qtmanagementdb";
const password = "PTRdwlWTMXduUKRQ";
// //mongodb+srv://shreeharitechnology2311:HuFissgrkayViWs2@vibsdatabase.upb0opt.mongodb.net/
const uri = `mongodb+srv://shreehariqtmanagement3028:${password}@${dbname}.8w1sa.mongodb.net/?retryWrites=true&w=majority`;
//const uri = `mongodb+srv://shreeharitechnology2311:${password}@vibsdatabase.upb0opt.mongodb.net/?retryWrites=true&w=majority`;

const client = new MongoClient(uri, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Initialize the MongoDB connection
async function initializeconnection() {
    try {
        await client.connect();
        console.log('Connected to MongoDB.');
    } catch (error) {
        console.error('MongoDB connection error:', error);
        throw error;
    }
}

// Function to get the database instance
async function getDB(dbName = dbname) {
    if (!client) {
        console.log('MongoDB connection is not established.');
        initializeconnection();
    }
    return client.db(dbName);
}

// Middleware to handle closing the connection gracefully when the app is terminated
async function handleapptermination() {
    if (client) {
        await client.close();
        console.log('Closed MongoDB connection.');
    }
}

module.exports = { initializeconnection, getDB, handleapptermination };